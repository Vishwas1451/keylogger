#If this gives you an error, just do pip install flask.
#If it STILL gives you an error, run cmd as administrator, then run this script.

from server import app

if __name__ == '__main__':
    app.run(port=80)
